clc; clear; close all;

%% Define the fuzzy inference system (FIS)
fis = mamfis('Name', 'CarParking');

% Input 1: Car Orientation Angle (phi)
fis = addInput(fis, [-90 90], 'Name', 'CarAngle'); % Degrees
fis = addMF(fis, 'CarAngle', 'trapmf', [-90 -90 -60 -30], 'Name', 'Sharp Left');
fis = addMF(fis, 'CarAngle', 'trimf', [-60 -30 0], 'Name', 'Slight Left');
fis = addMF(fis, 'CarAngle', 'trimf', [-30 0 30], 'Name', 'Centered');
fis = addMF(fis, 'CarAngle', 'trimf', [0 30 60], 'Name', 'Slight Right');
fis = addMF(fis, 'CarAngle', 'trapmf', [30 60 90 90], 'Name', 'Sharp Right');

% Input 2: Distance to Parking Spot
fis = addInput(fis, [0 100], 'Name', 'Distance'); % Distance in meters
fis = addMF(fis, 'Distance', 'trapmf', [0 0 10 30], 'Name', 'Near');
fis = addMF(fis, 'Distance', 'trimf', [10 50 90], 'Name', 'Medium');
fis = addMF(fis, 'Distance', 'trapmf', [50 90 100 100], 'Name', 'Far');

% Output: Steering Angle (theta)
fis = addOutput(fis, [-30 30], 'Name', 'SteeringAngle'); % Degrees
fis = addMF(fis, 'SteeringAngle', 'trapmf', [-30 -30 -20 -10], 'Name', 'Sharp Left');
fis = addMF(fis, 'SteeringAngle', 'trimf', [-20 -10 0], 'Name', 'Slight Left');
fis = addMF(fis, 'SteeringAngle', 'trimf', [-5 0 5], 'Name', 'Straight');
fis = addMF(fis, 'SteeringAngle', 'trimf', [0 10 20], 'Name', 'Slight Right');
fis = addMF(fis, 'SteeringAngle', 'trapmf', [10 20 30 30], 'Name', 'Sharp Right');

%% Define the Fuzzy Rule Base
rules = [
    1 3 1 1 1; % If car angle is Sharp Left and distance is Near, then Sharp Left
    2 3 2 1 1; % If car angle is Slight Left and distance is Near, then Slight Left
    3 3 3 1 1; % If car angle is Centered and distance is Near, then Straight
    4 3 4 1 1; % If car angle is Slight Right and distance is Near, then Slight Right
    5 3 5 1 1; % If car angle is Sharp Right and distance is Near, then Sharp Right

    1 2 1 1 1; % If car angle is Sharp Left and distance is Medium, then Sharp Left
    2 2 2 1 1; % If car angle is Slight Left and distance is Medium, then Slight Left
    3 2 3 1 1; % If car angle is Centered and distance is Medium, then Straight
    4 2 4 1 1; % If car angle is Slight Right and distance is Medium, then Slight Right
    5 2 5 1 1; % If car angle is Sharp Right and distance is Medium, then Sharp Right

    1 1 1 1 1; % If car angle is Sharp Left and distance is Far, then Sharp Left
    2 1 2 1 1; % If car angle is Slight Left and distance is Far, then Slight Left
    3 1 3 1 1; % If car angle is Centered and distance is Far, then Straight
    4 1 4 1 1; % If car angle is Slight Right and distance is Far, then Slight Right
    5 1 5 1 1; % If car angle is Sharp Right and distance is Far, then Sharp Right
];

% Add rules to the FIS
fis = addrule(fis, rules);

%% Simulate the Fuzzy Control System
car_angle = -45; % Initial car angle (degrees)
distance_to_spot = 70; % Initial distance to parking spot (meters)

% Evaluate the Fuzzy Logic Controller
steering_angle = evalfis([car_angle, distance_to_spot], fis);

% Display the calculated steering angle
disp(['Steering Angle: ', num2str(steering_angle), ' degrees']);

%% Simulate Trajectory of Car Parking
dt = 0.1; % Time step
num_steps = 100; % Number of simulation steps

% Initialize state variables
x = 20; % Initial x position
y = 10; % Initial y position
phi = -45; % Initial orientation (degrees)
trajectory_x = zeros(1, num_steps);
trajectory_y = zeros(1, num_steps);

b = 2; % Car wheelbase

for k = 1:num_steps
    % Evaluate FLC for each step
    steering_angle = evalfis([phi, distance_to_spot], fis);
    
    % Convert steering angle to radians
    theta = deg2rad(steering_angle);
    
    % Update position using kinematic model
    x = x + cosd(phi) * cos(theta) * dt + sind(theta) * sind(phi) * dt;
    y = y + sind(phi) * cos(theta) * dt - sind(theta) * sind(phi) * dt;
    phi = phi - (2 * sind(theta) * sind(phi)) / b * dt;
    
    % Store trajectory
    trajectory_x(k) = x;
    trajectory_y(k) = y;
    
    % Reduce distance (car is moving towards parking spot)
    distance_to_spot = max(0, distance_to_spot - 1);
end

%% Plot Trajectory of the Car
figure;
plot(trajectory_x, trajectory_y, 'b', 'LineWidth', 2);
hold on;
plot(0, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r'); % Target parking spot
xlabel('X Position');
ylabel('Y Position');
title('Car Parking Trajectory');
legend('Car Path', 'Parking Spot');
grid on;
axis equal;

%% Plot Fuzzy System
figure;
plotfis(fis);

% Plot Membership Functions
figure;
subplot(3, 1, 1);
plotmf(fis, 'input', 1);
title('Car Orientation Angle Membership Functions');

subplot(3, 1, 2);
plotmf(fis, 'input', 2);
title('Distance to Parking Spot Membership Functions');

subplot(3, 1, 3);
plotmf(fis, 'output', 1);
title('Steering Angle Membership Functions');
