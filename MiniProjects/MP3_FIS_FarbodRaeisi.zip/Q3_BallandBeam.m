clc; clear; close all;

%% 📌 Load and Prepare Data
data = load('ballbeam.dat'); % Load dataset
U = data(:, 1); % Input: Beam Angle
Y = data(:, 2); % Output: Ball Position
Ts = 0.1; % Sampling Time

% 📌 Normalize Data Using Z-Score (Better Performance)
U_norm = (U - mean(U)) / std(U);
Y_norm = (Y - mean(Y)) / std(Y);

% 📌 Create Dynamic Model by Adding Past Inputs
num_samples = length(U);
train_size = round(0.7 * num_samples);

train_input = [U_norm(1:train_size-1), U_norm(2:train_size)];
train_output = Y_norm(2:train_size);

test_input = [U_norm(train_size:end-1), U_norm(train_size+1:end)];
test_output = Y_norm(train_size+1:end);

%% 📌 Create Initial FIS Using Grid Partitioning (Better Rule Definition)
opt = genfisOptions('GridPartition');
opt.NumMembershipFunctions = 5; % More Membership Functions for Precision
opt.InputMembershipFunctionType = 'gaussmf'; % Use Gaussian MFs (Smoother)

fis = genfis(train_input, train_output, opt);

% Display Initial FIS Structure
figure;
plotfis(fis);
title('Initial FIS Structure');

%% 📌 Train ANFIS Model (Higher Epochs, Avoid Overfitting)
anfis_opt = anfisOptions('InitialFIS', fis, 'EpochNumber', 300);
anfis_opt.ValidationData = [test_input, test_output]; % Use test data for validation
anfis_opt.DisplayANFISInformation = 1; % Show training details

trained_fis = anfis([train_input, train_output], anfis_opt);

%% 📌 Evaluate Model Performance
predicted_output = evalfis(test_input, trained_fis);

% 📌 Compute Performance Metrics
mse_error = mean((predicted_output - test_output).^2);
rmse_error = sqrt(mse_error);
mae_error = mean(abs(predicted_output - test_output));

disp(['ANFIS MSE Error: ', num2str(mse_error)]);
disp(['ANFIS RMSE Error: ', num2str(rmse_error)]);
disp(['ANFIS MAE Error: ', num2str(mae_error)]);

%% 📌 Plot Membership Functions of Trained FIS (Input Only)
figure;
plotmf(trained_fis, 'input', 1);
title('Input Membership Functions (Beam Angle)');

%% 📌 Display Rule Base (Instead of Output MFs)
figure;
ruleview(trained_fis);
title('ANFIS Rule Base');

%% 📌 Plot Comparison of True vs. Predicted Outputs
figure;
plot(test_output, 'r', 'LineWidth', 1.5); hold on;
plot(predicted_output, 'b--', 'LineWidth', 1.5);
xlabel('Sample Index');
ylabel('Ball Position');
legend('True Output', 'Predicted Output (ANFIS)');
title('ANFIS Model Performance on Test Data');
grid on;

%% 📌 Simulate Ball Trajectory Using ANFIS
time_vector = (0:Ts:(length(test_output)-1)*Ts)';
ball_trajectory = evalfis(test_input, trained_fis);

figure;
plot(time_vector, test_output, 'r', 'LineWidth', 1.5); hold on;
plot(time_vector, ball_trajectory, 'b--', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Ball Position');
legend('Actual Position', 'ANFIS Predicted Position');
title('Ball & Beam System Trajectory Prediction');
grid on;

%% 📌 Plot Error Analysis
error_signal = test_output - predicted_output;

figure;
plot(time_vector, error_signal, 'k', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Prediction Error');
title('Error Analysis: ANFIS Prediction vs. Actual');
grid on;

%% 📌 Histogram of Prediction Errors
figure;
histogram(error_signal, 20, 'FaceColor', 'r');
xlabel('Prediction Error');
ylabel('Frequency');
title('Histogram of Prediction Errors');
grid on;
