clc; clear; close all;

%% Load the Dataset
data = load('steamgen.dat'); % Load dataset
time_steps = data(:,1); % Time vector
inputs = data(:,2:5);  % Inputs: Fuel, Air, Reference Level, Disturbance
outputs = data(:,6:9); % Outputs: Drum Pressure, Oxygen, Water Level, Steam Flow

%% Preprocessing: Normalize Inputs & Outputs
inputs = normalize(inputs, 'range', [0 1]); 
outputs = normalize(outputs, 'range', [0 1]); 

%% Downsample Data for Efficient Training
sample_rate = 5;  % Reduce dataset to prevent memory issues
inputs = inputs(1:sample_rate:end, :);
outputs = outputs(1:sample_rate:end, :);

%% Split Data into Training & Testing
split_ratio = 0.7; % 70% Training, 30% Testing
num_train = floor(split_ratio * size(inputs,1));

train_input = inputs(1:num_train, :);
train_output = outputs(1:num_train, :);
test_input = inputs(num_train+1:end, :);
test_output = outputs(num_train+1:end, :);

%% Generate and Train ANFIS for All Outputs
radii = 0.5; % Clustering sensitivity (Adjust 0.2 - 0.8 for best results)
trained_fis = cell(1,4); % Store FIS models
anfis_pred = zeros(size(test_output)); % Store predictions

for i = 1:4
    fis = genfis2(train_input, train_output(:, i), radii); % Generate FIS for each output
    anfis_opt = anfisOptions('InitialFIS', fis, 'EpochNumber', 100);
    anfis_opt.DisplayErrorValues = true;
    anfis_opt.DisplayStepSize = true;
    anfis_opt.ValidationData = [test_input, test_output(:, i)]; 
    trained_fis{i} = anfis([train_input, train_output(:, i)], anfis_opt);
    anfis_pred(:, i) = evalfis(trained_fis{i}, test_input);
end

%% Compute Errors for Each Output
mse_error = mean((anfis_pred - test_output).^2);
rmse_error = sqrt(mse_error);
mae_error = mean(abs(anfis_pred - test_output));

% Display Errors
for i = 1:4
    disp(['Output ', num2str(i), ' - ANFIS MSE Error: ', num2str(mse_error(i))]);
    disp(['Output ', num2str(i), ' - ANFIS RMSE Error: ', num2str(rmse_error(i))]);
    disp(['Output ', num2str(i), ' - ANFIS MAE Error: ', num2str(mae_error(i))]);
end

%% Plot Comparison: True vs Predicted for All Outputs
output_names = {'Drum Pressure', 'Excess Oxygen', 'Water Level', 'Steam Flow'};

figure;
for i = 1:4
    subplot(2,2,i);
    plot(1:length(test_output(:,i)), test_output(:,i), 'r', 'LineWidth', 1.5);
    hold on;
    plot(1:length(anfis_pred(:,i)), anfis_pred(:,i), 'b--', 'LineWidth', 1.5);
    xlabel('Sample Index'); ylabel(output_names{i});
    legend('True Output', 'ANFIS Predicted Output');
    title(['ANFIS Prediction vs True Data for ', output_names{i}]);
    grid on;
end

%% Plot Membership Functions (Inputs Only)
figure;
subplot(2,1,1);
plotmf(trained_fis{1}, 'input', 1);
title('Membership Functions for Input 1 (Fuel)');

subplot(2,1,2);
plotmf(trained_fis{1}, 'input', 2);
title('Membership Functions for Input 2 (Air)');

%% Plot Rule Surface Instead of Output MF
figure;
gensurf(trained_fis{1});
title('ANFIS Rule Surface Visualization for Output 1 (Drum Pressure)');
