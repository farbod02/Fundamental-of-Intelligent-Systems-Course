clc; clear; close all;

%% Load and Preprocess the Air Quality Dataset
data = readtable('AirQualityUCI.csv'); % Load CSV file

% Select relevant columns (ignoring Date & Time)
selected_features = {'CO_GT_', 'PT08_S1_CO_', 'NMHC_GT_', 'C6H6_GT_'};
selected_outputs = {'NOx_GT_', 'PT08_S2_NMHC_', 'NO2_GT_', 'PT08_S3_NOx_'};

% Convert selected columns to numerical arrays
input_data = table2array(data(:, selected_features));
output_data = table2array(data(:, selected_outputs));

% Handle missing values by replacing NaNs with column means
input_data = fillmissing(input_data, 'movmean', 5);
output_data = fillmissing(output_data, 'movmean', 5);

% Normalize the data to [0,1] range
input_data = normalize(input_data, 'range');
output_data = normalize(output_data, 'range');

%% Split Data into Training (60%), Validation (20%), and Test (20%)
num_samples = size(input_data, 1);
train_size = floor(0.6 * num_samples);
val_size = floor(0.2 * num_samples);
test_size = num_samples - (train_size + val_size);

train_input = input_data(1:train_size, :);
train_output = output_data(1:train_size, :);

val_input = input_data(train_size+1:train_size+val_size, :);
val_output = output_data(train_size+1:train_size+val_size, :);

test_input = input_data(train_size+val_size+1:end, :);
test_output = output_data(train_size+val_size+1:end, :);

%% Train ANFIS Model (Using genfis2 with Corrected Parameters)
disp('Training ANFIS Model...');
cluster_influence_range = 0.5; % Adjust for better clustering

% Generate Initial FIS using Subtractive Clustering
fis = genfis2(train_input, train_output(:,1), cluster_influence_range);

% Train ANFIS
anfis_opt = anfisOptions('InitialFIS', fis, 'EpochNumber', 100);
anfis_opt.ValidationData = [val_input, val_output(:,1)];
anfis_opt.DisplayErrorValues = true;
anfis_opt.DisplayStepSize = true;
trained_fis = anfis([train_input, train_output(:,1)], anfis_opt);

% Test ANFIS
anfis_predicted = evalfis(test_input, trained_fis);

%% Train RBF Neural Network
disp('Training RBF Model...');
num_hidden = 20; % Number of neurons in RBF hidden layer
rbf_net = newrb(train_input', train_output(:,1)', 0.01, 1, num_hidden, 10);

% Test RBF Model
rbf_predicted = rbf_net(test_input')';

%% Evaluate Models
anfis_mse = mean((anfis_predicted - test_output(:,1)).^2);
rbf_mse = mean((rbf_predicted - test_output(:,1)).^2);

disp(['ANFIS MSE: ', num2str(anfis_mse)]);
disp(['RBF MSE: ', num2str(rbf_mse)]);

%% Plot Results
figure;
plot(1:length(test_output(:,1)), test_output(:,1), 'r', 'LineWidth', 1.5);
hold on;
plot(1:length(anfis_predicted), anfis_predicted, 'b--', 'LineWidth', 1.5);
plot(1:length(rbf_predicted), rbf_predicted, 'g-.', 'LineWidth', 1.5);
xlabel('Sample Index');
ylabel('Output Value');
legend('True Output', 'ANFIS Predicted', 'RBF Predicted');
title('Comparison of ANFIS and RBF Predictions');
grid on;
