clc; clear; close all;

%% Define the System Transfer Function
numerator = [1 0];  % s
denominator = [2 1]; % s + 1
G = tf(numerator, denominator);

%% Ziegler-Nichols Tuning (Experimental Data)
Ku = 1.4;   % Ultimate gain (experimentally determined)
Pu = 6.2;   % Ultimate period (experimentally determined)

% Calculate PID parameters
Kp = 0.6 * Ku;
Ti = 0.5 * Pu;
Td = 0.125 * Pu;
Ki = Kp / Ti;
Kd = Kp * Td;

