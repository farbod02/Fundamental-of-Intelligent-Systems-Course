clc; clear; close all;

%% Define the Transfer Function of the System
numerator = [1 0];  % s
denominator = [1 1]; % s + 1
sys = tf(numerator, denominator);

%% Design Fuzzy Logic Controller (FLC)
fis = mamfis('Name', 'FuzzyPID');

% Add Inputs: Error (e) and Change in Error (Δe)
fis = addInput(fis, [-1 1], 'Name', 'Error');  % Error range
fis = addInput(fis, [-1 1], 'Name', 'ChangeInError'); % Change in error range

% Add Output: Control Action (u)
fis = addOutput(fis, [-10 10], 'Name', 'ControlAction'); % Control output range

% Define Membership Functions for 'Error'
fis = addMF(fis, 'Error', 'trimf', [-1 -0.5 0], 'Name', 'Negative');
fis = addMF(fis, 'Error', 'trimf', [-0.5 0 0.5], 'Name', 'Zero');
fis = addMF(fis, 'Error', 'trimf', [0 0.5 1], 'Name', 'Positive');

% Define Membership Functions for 'ChangeInError'
fis = addMF(fis, 'ChangeInError', 'trimf', [-1 -0.5 0], 'Name', 'Negative');
fis = addMF(fis, 'ChangeInError', 'trimf', [-0.5 0 0.5], 'Name', 'Zero');
fis = addMF(fis, 'ChangeInError', 'trimf', [0 0.5 1], 'Name', 'Positive');

% Define Membership Functions for 'ControlAction'
fis = addMF(fis, 'ControlAction', 'trimf', [-10 -5 0], 'Name', 'Negative');
fis = addMF(fis, 'ControlAction', 'trimf', [-5 0 5], 'Name', 'Zero');
fis = addMF(fis, 'ControlAction', 'trimf', [0 5 10], 'Name', 'Positive');

% Define Fuzzy Rules
rules = [ ...
    "If Error is Negative and ChangeInError is Negative then ControlAction is Negative";
    "If Error is Negative and ChangeInError is Zero then ControlAction is Negative";
    "If Error is Negative and ChangeInError is Positive then ControlAction is Zero";
    "If Error is Zero and ChangeInError is Negative then ControlAction is Negative";
    "If Error is Zero and ChangeInError is Zero then ControlAction is Zero";
    "If Error is Zero and ChangeInError is Positive then ControlAction is Positive";
    "If Error is Positive and ChangeInError is Negative then ControlAction is Zero";
    "If Error is Positive and ChangeInError is Zero then ControlAction is Positive";
    "If Error is Positive and ChangeInError is Positive then ControlAction is Positive"];
fis = addRule(fis, rules);

% Display Fuzzy System
figure;
plotmf(fis, 'input', 1);
title('Membership Functions for Error');

figure;
plotmf(fis, 'input', 2);
title('Membership Functions for Change in Error');

figure;
plotmf(fis, 'output', 1);
title('Membership Functions for Control Action');

%% Simulate Fuzzy PID Controller
% Define Simulation Parameters
t = 0:0.01:10; % Time vector
ref_signal = ones(size(t)); % Step input
error_signal = ref_signal;  % Initialize error

% Simulate Control Action using Fuzzy Logic
control_action = zeros(size(t));
for k = 2:length(t)
    delta_e = error_signal(k) - error_signal(k-1); % Change in error
    control_action(k) = evalfis(fis, [error_signal(k), delta_e]); % Compute control action
end

% Create a PID Controller with Tuned Gains from Fuzzy Output
Kp = 1;
Ki = 1;
Kd = 1;
PID = pid(Kp, Ki, Kd);

% Apply PID Controller to System
closed_loop_sys = feedback(PID * sys, 1);

% Simulate Step Response
[y, ~] = step(closed_loop_sys, t);

%% Plot Response
figure;
plot(t, y, 'b', 'LineWidth', 2);
hold on;
plot(t, ref_signal, 'r--', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('Output');
legend('Fuzzy PID Response', 'Reference Signal');
title('Step Response of System with Fuzzy PID Controller');
grid on;
