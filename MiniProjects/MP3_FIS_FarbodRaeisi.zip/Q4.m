clc; clear; close all;

%% Step 1: Generate Data Based on Given Equation
N = 1000; % Number of samples
u = rand(N,1) * 2 - 1; % Input u_k in range [-1, 1]

% Define function g[u]
g_u = 0.6 * sin(pi * u) + 0.3 * sin(3 * pi * u) + 0.1 * sin(5 * pi * u);

% Initialize y values
y = zeros(N,1);
y(1) = 0; % Initial condition
y(2) = 0; % Initial condition

% Compute y(k+1) based on given equation
for k = 3:N
    y(k) = 0.3 * y(k-1) + 0.6 * y(k-2) + g_u(k-2);
end

% Prepare Input-Output Data
data = [u(1:N-2), y(1:N-2), y(2:N-1), y(3:N)]; % [u_k, y_k, y_k-1, y_k+1]

%% Step 2: Split Data into Training and Testing
train_ratio = 0.7;
train_size = floor(train_ratio * size(data,1));

train_input = data(1:train_size, 1:3); % [u_k, y_k, y_k-1]
train_output = data(1:train_size, 4);  % y_k+1

test_input = data(train_size+1:end, 1:3);
test_output = data(train_size+1:end, 4);

%% Step 3: Generate Fuzzy Inference System (ANFIS)
disp("Generating ANFIS model...");

% Generate initial FIS using grid partitioning
opt = genfisOptions('GridPartition');
opt.NumMembershipFunctions = 3;
opt.InputMembershipFunctionType = 'gaussmf';

% Create initial FIS
fis = genfis(train_input, train_output, opt);

%% Step 4: Train ANFIS Model
anfis_opt = anfisOptions('InitialFIS', fis, 'EpochNumber', 100);
anfis_opt.ValidationData = [test_input, test_output]; % Validation Data

% Train ANFIS
trained_fis = anfis([train_input, train_output], anfis_opt);

%% Step 5: Evaluate ANFIS Performance
predicted_output = evalfis(test_input, trained_fis);

% Compute Errors
MSE = mean((predicted_output - test_output).^2);
RMSE = sqrt(MSE);
MAE = mean(abs(predicted_output - test_output));

disp(['ANFIS MSE Error: ', num2str(MSE)]);
disp(['ANFIS RMSE Error: ', num2str(RMSE)]);
disp(['ANFIS MAE Error: ', num2str(MAE)]);

%% Step 6: Plot Results

% Plot Real vs. Predicted Outputs
figure;
plot(1:length(test_output), test_output, 'r', 'LineWidth', 1.5);
hold on;
plot(1:length(predicted_output), predicted_output, 'b--', 'LineWidth', 1.5);
xlabel('Sample Index');
ylabel('Output y_{k+1}');
legend('Real Output', 'Predicted Output (ANFIS)');
title('ANFIS Model: Real vs Predicted Outputs');
grid on;

% Plot Membership Functions
figure;
subplot(3,1,1);
plotmf(trained_fis, 'input', 1);
title('Input Membership Functions (u_k)');

subplot(3,1,2);
plotmf(trained_fis, 'input', 2);
title('Input Membership Functions (y_k)');

subplot(3,1,3);
plotmf(trained_fis, 'input', 3);
title('Input Membership Functions (y_k-1)');

% Display Fuzzy Rules
figure;
plotfis(trained_fis);
title('Fuzzy Inference System');

